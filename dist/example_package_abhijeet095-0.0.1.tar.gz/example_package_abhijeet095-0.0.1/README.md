Following instructions from https://packaging.python.org/en/latest/tutorials/packaging-projects/


## Questions

- what does the toml file do?